package com.lyle.calculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {


    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        textView = findViewById(R.id.textView)

        val edtnum1 =findViewById<EditText>(R.id.edtnum1)
        val edtnum2 = findViewById<EditText>(R.id.edtNum2)

        val btnadd =findViewById<Button>(R.id.btnadd)
        btnadd.setOnClickListener{
        if (edtnum1.text.toString()!="" && edtnum2.text.toString()!=""){


            val sum = edtnum1.text.toString().trim().toBigInteger()+edtnum2.text.toString().trim().toBigInteger()
            Toast.makeText(this,"The Sum is $sum.", Toast.LENGTH_LONG).show();

       }else {
           Toast.makeText(this,"Please Enter Two Numbers.", Toast.LENGTH_LONG).show();
       }

        }

        val btnsub =findViewById<Button>(R.id.btnsub)
        btnsub.setOnClickListener{
            if (edtnum1.text.toString()!="" && edtnum2.text.toString()!=""){


                val sub = edtnum1.text.toString().trim().toBigInteger()-edtnum2.text.toString().trim().toBigInteger()


                Toast.makeText(this,"The Difference is $sub.", Toast.LENGTH_LONG).show();

            }else {

                Toast.makeText(this,"Please Enter Two Numbers.", Toast.LENGTH_LONG).show();
            }
        }
        val btndiv =findViewById<Button>(R.id.btndiv)
        btndiv.setOnClickListener{
            if (edtnum2.text.toString().toInt() == 0) {
                Toast.makeText(
                    this,
                    "Please choose another number that is not zero.",
                    Toast.LENGTH_LONG
                ).show();
            }else
            if (edtnum1.text.toString()!="" && edtnum2.text.toString()!=""){


                val div = edtnum1.text.toString().trim().toBigInteger()/edtnum2.text.toString().trim().toBigInteger()
                Toast.makeText(this,"The Quotient is $div.", Toast.LENGTH_LONG).show();


            }
        }
        val btnmult =findViewById<Button>(R.id.btnmult)
        btnmult.setOnClickListener{
            if (edtnum1.text.toString()!="" && edtnum2.text.toString()!=""){


                val mult = edtnum1.text.toString().trim().toBigInteger()*edtnum2.text.toString().trim().toBigInteger()
                Toast.makeText(this,"The Product is $mult.", Toast.LENGTH_LONG).show();

            }else {
                Toast.makeText(this,"Please Enter Two Numbers..", Toast.LENGTH_LONG).show();
            }
        }
        val btnpow =findViewById<Button>(R.id.btnpow)
        btnpow.setOnClickListener{

        }
        val btnsqr =findViewById<Button>(R.id.btnsqr)
        btnsqr.setOnClickListener{

        }
        val btnstat =findViewById<Button>(R.id.btnstat)
        btnstat.setOnClickListener{

        }


    }
}